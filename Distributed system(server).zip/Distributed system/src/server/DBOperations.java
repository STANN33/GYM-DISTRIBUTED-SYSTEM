package server;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import rmi.DBOInterface;


public class DBOperations {

    // Create
    public String insertOperation(int userId, String userName, String exercise, Integer sets, Integer reps, Double weight) {
        String output = "";

        try {
            String query = "INSERT INTO Workout_Log (log_id, user_name, exercise_name, sets, reps, weight) VALUES (?,?,?,?,?,?)";
            DBConnection dbc = new DBConnection();
            PreparedStatement pst = dbc.con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.setString(2, userName);
            pst.setString(3, exercise);
            pst.setObject(4, sets, Types.INTEGER);
            pst.setObject(5, reps, Types.INTEGER);
            pst.setObject(6, weight, Types.DOUBLE);

            int rows = pst.executeUpdate();
            output = rows + " row(s) inserted successfully.";
            dbc.con.close();
        } catch (SQLException sqle) {
            output = "Insert operation failed:\n" + sqle.getMessage();
        }

        return output;
    }

    // Read single
    public String[] selectOperation(int logId) {
        String[] result = new String[5];

        try {
            String query = "SELECT user_name, exercise_name, sets, reps, weight FROM Workout_Log WHERE log_id = ?";
            DBConnection dbc = new DBConnection();
            PreparedStatement pst = dbc.con.prepareStatement(query);
            pst.setInt(1, logId);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                result[0] = rs.getString("user_name");
                result[1] = rs.getString("exercise_name");
                result[2] = rs.getObject("sets") != null ? rs.getString("sets") : null;
                result[3] = rs.getObject("reps") != null ? rs.getString("reps") : null;
                result[4] = rs.getObject("weight") != null ? rs.getString("weight") : null;
            }

            dbc.con.close();
        } catch (SQLException sqle) {
            System.out.println("Select operation failed:\n" + sqle.getMessage());
        }

        return result;
    }

    // Read all
    public List<String> selectAllOperation() {
        List<String> output = new ArrayList<>();
        

        try {
            String query = "SELECT * FROM Workout_Log";
            DBConnection dbc = new DBConnection();
            PreparedStatement pst = dbc.con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String line = rs.getInt("log_id") + " | " +
                              rs.getString("user_name") + " | " +
                              rs.getString("exercise_name") + " | " +
                              rs.getObject("sets") + "x" + rs.getObject("reps") + " @ " +
                              rs.getObject("weight") + "kg";
                output.add(line);
            }

            dbc.con.close();
        } catch (SQLException sqle) {
            System.out.println("View All Error:\n" + sqle.getMessage());
        }

        return output;
    }

    // Update
  public String updateOperation(int logId, String username, String exercise, Integer sets, Integer reps, Double weight) {
    String output = "";

    try {
        String query = "UPDATE Workout_Log SET user_name = ?, exercise_name = ?, sets = ?, reps = ?, weight = ? WHERE log_id = ?";
        DBConnection dbc = new DBConnection();
        PreparedStatement pst = dbc.con.prepareStatement(query);
        pst.setString(1, username);
        pst.setString(2, exercise);
        pst.setObject(3, sets, java.sql.Types.INTEGER);
        pst.setObject(4, reps, java.sql.Types.INTEGER);
        pst.setObject(5, weight, java.sql.Types.DOUBLE);
        pst.setInt(6, logId);

        int rows = pst.executeUpdate();
        output = rows + " row(s) updated.";
        dbc.con.close();
    } catch (SQLException sqle) {
        output = "Update failed: " + sqle.getMessage();
    }

    return output;

  }
    // Delete
  public void deleteOperation(int logId) {
    String output = "";

    try {
        String query = "DELETE FROM Workout_Log WHERE log_id = ?";
        DBConnection dbc = new DBConnection();
        PreparedStatement pst = dbc.con.prepareStatement(query);
        pst.setInt(1, logId);

        int rows = pst.executeUpdate();
        output = rows + " row(s) deleted successfully.";
        System.out.println(output);

        dbc.con.close();
    } catch (SQLException sqle) {
        output = "Delete operation failed:\n" + sqle.getMessage();
        System.out.println(output);
    }
}

    public void deleteWorkout(int logId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void updateWorkout(DBOInterface.WorkoutLog log) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public List<DBOInterface.WorkoutLog> getAllWorkouts() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void addWorkout(DBOInterface.WorkoutLog log) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   
    }



