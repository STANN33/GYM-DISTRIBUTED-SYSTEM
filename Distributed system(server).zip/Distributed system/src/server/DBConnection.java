package server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
     Connection con;

    public DBConnection() {
        try {
            String url = "jdbc:postgresql://localhost:5432/replog"; 
            String username = "postgres";                      
            String password = "Mutiga56@";                   

            con = DriverManager.getConnection(url, username, password);
            System.out.println("Connection to replog database established successfully.");
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
        }
    }
}