package rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface DBOInterface extends Remote {
    void addWorkout(WorkoutLog log) throws RemoteException;
    List<WorkoutLog> getAllWorkouts() throws RemoteException;
    void updateWorkout(WorkoutLog log) throws RemoteException;
    void deleteWorkout(int logId) throws RemoteException;

    String insertOperation(int logId, String username, String exerciseName,
                           Integer sets, Integer reps, Double weight) throws RemoteException;

    String[] selectOperation(int logId) throws RemoteException;

    void updateOperation(int logId, String username, String exerciseName,
                         Integer sets, Integer reps, Double weight) throws RemoteException;

    void deleteOperation(int logId) throws RemoteException;

    String[] selectAllOperation() throws RemoteException;

    public static class WorkoutLog {

        public WorkoutLog() {
        }
    }
}
