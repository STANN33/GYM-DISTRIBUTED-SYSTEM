package rmi;

import server.DBOperations;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

public class DBOInterfaceImpl extends UnicastRemoteObject implements DBOInterface {

    private final DBOperations dbo;

    public DBOInterfaceImpl() throws RemoteException {
        super();
        dbo = new DBOperations();
    }

    @Override
    public void addWorkout(WorkoutLog log) throws RemoteException {
        dbo.addWorkout(log);
    }

    @Override
    public List<WorkoutLog> getAllWorkouts() throws RemoteException {
        return dbo.getAllWorkouts();
    }

    @Override
    public void updateWorkout(WorkoutLog log) throws RemoteException {
        dbo.updateWorkout(log);
    }

    @Override
    public void deleteWorkout(int logId) throws RemoteException {
        dbo.deleteWorkout(logId);
    }

    @Override
    public String insertOperation(int logId, String username, String exerciseName, Integer sets, Integer reps, Double weight) throws RemoteException {
        return dbo.insertOperation(logId, username, exerciseName, sets, reps, weight);
    }

    @Override
    public String[] selectOperation(int logId) throws RemoteException {
        return dbo.selectOperation(logId);
    }


    @Override
    public void updateOperation(int logId, String username, String exerciseName, Integer sets, Integer reps, Double weight) throws RemoteException {
        dbo.updateOperation(logId, username, exerciseName, sets, reps, weight);
    }

    @Override
    public void deleteOperation(int logId) throws RemoteException {
        dbo.deleteOperation(logId);
    }

    
@Override
public String[] selectAllOperation() throws RemoteException {
    ArrayList<String> logs = (ArrayList<String>) dbo.selectAllOperation();
    return logs.toArray(new String[0]);
}


}
