package rmi;

import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;

public class ServerApp {
    public static void main(String[] args) {
        try {
            DBOInterface dboi = new DBOInterfaceImpl();  
            Registry rmiRegistry = LocateRegistry.createRegistry(1099);
            rmiRegistry.bind("DBOperations", dboi);
            System.out.println(" Server is running...");
        } catch (RemoteException | AlreadyBoundException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }
}
