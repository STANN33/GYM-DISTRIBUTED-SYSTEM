package ClientProgram;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ClientGui extends Application {

    private DBOInterface dboService;

    @Override
    public void start(Stage primaryStage) {
        connectToServer();

        Label titleLb = new Label("💪 Workout Log Manager");
        titleLb.setStyle("-fx-text-fill:salmon; -fx-font-size: 30px; -fx-font-weight: bold;");

        Image gymImage = new Image("file:C:/Users/ngugi/OneDrive/Pictures/gympicture.jpg");
        ImageView imageView = new ImageView(gymImage);
        imageView.setFitWidth(320);
        imageView.setPreserveRatio(true);

        TextField idTf = new TextField(); idTf.setPromptText("Log ID");
        TextField nameTf = new TextField(); nameTf.setPromptText("Username");
        TextField exTf = new TextField(); exTf.setPromptText("Exercise");
        TextField setsTf = new TextField(); setsTf.setPromptText("Sets");
        TextField repsTf = new TextField(); repsTf.setPromptText("Reps");
        TextField wtTf = new TextField(); wtTf.setPromptText("Weight");

        TextArea responseArea = new TextArea();
        responseArea.setEditable(false);
        responseArea.setPrefHeight(300);

        Button insertBtn = new Button("Insert");
        Button readBtn = new Button("Read");
        Button updateBtn = new Button("Update");
        Button deleteBtn = new Button("Delete");
        Button viewAllBtn = new Button("View All");
        insertBtn.setStyle(btnStyle());
        readBtn.setStyle(btnStyle());
        updateBtn.setStyle(btnStyle());
        deleteBtn.setStyle(btnStyle());
        viewAllBtn.setStyle(btnStyle());


        insertBtn.setOnAction(e -> {
            try {
                String output = dboService.insertOperation(
                        Integer.parseInt(idTf.getText()),
                        nameTf.getText(),
                        exTf.getText(),
                        parseInt(setsTf.getText()),
                        parseInt(repsTf.getText()),
                        parseDouble(wtTf.getText())
                );
                responseArea.setText(output);
            } catch (Exception ex) {
                responseArea.setText("Insert failed: " + ex.getMessage());
            }
        });

        readBtn.setOnAction(e -> {
            try {
                int id = Integer.parseInt(idTf.getText());
                String[] res = dboService.selectOperation(id);
                if (res != null && res.length == 5) {
                    nameTf.setText(res[0]);
                    exTf.setText(res[1]);
                    setsTf.setText(res[2]);
                    repsTf.setText(res[3]);
                    wtTf.setText(res[4]);
                    responseArea.setText(" Entry loaded.");
                } else {
                    responseArea.setText("️ No entry found.");
                }
            } catch (Exception ex) {
                responseArea.setText("Read failed: " + ex.getMessage());
            }
        });

        updateBtn.setOnAction(e -> {
            try {
                dboService.updateOperation(
                        Integer.parseInt(idTf.getText()),
                        nameTf.getText(),
                        exTf.getText(),
                        parseInt(setsTf.getText()),
                        parseInt(repsTf.getText()),
                        parseDouble(wtTf.getText())
                );
                responseArea.setText("✏️ Entry updated.");
            } catch (Exception ex) {
                responseArea.setText("Update failed: " + ex.getMessage());
            }
        });

        deleteBtn.setOnAction(e -> {
            try {
                dboService.deleteOperation(Integer.parseInt(idTf.getText()));
                clearFields(idTf, nameTf, exTf, setsTf, repsTf, wtTf);
                responseArea.setText("Entry deleted.");
            } catch (Exception ex) {
                responseArea.setText("Delete failed: " + ex.getMessage());
            }
        });
        viewAllBtn.setOnAction(e -> {
    try {
        String[] allLogs = dboService.selectAllOperation();
        if (allLogs.length == 0) {
            responseArea.setText("️ No workout logs found.");
        } else {
            StringBuilder sb = new StringBuilder(" All Workout Logs:\n\n");
            for (String log : allLogs) {
                sb.append(log).append("\n");
            }
            responseArea.setText(sb.toString());
        }
    } catch (Exception ex) {
        responseArea.setText("View All failed: " + ex.getMessage());
    }
});


       VBox layout = new VBox(titleLb, imageView, idTf, nameTf, exTf, setsTf, repsTf, wtTf,
                       insertBtn, readBtn, updateBtn, deleteBtn, viewAllBtn, responseArea);

        layout.setAlignment(Pos.CENTER);
        layout.setSpacing(10);
        layout.setPadding(new Insets(30));
        layout.setStyle("-fx-background-color:lemonchiffon;");

        Scene scene = new Scene(layout, 600, 720);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Workout Tracker");
        primaryStage.show();
    }

private void connectToServer() {
    try {
        Registry registry = LocateRegistry.getRegistry("192.168.56.1", 1099);
        dboService = (DBOInterface) registry.lookup("DBOperations");
        System.out.println("Connected to RMI server.");
    } catch (Exception e) {
        dboService = null;
        System.out.println("❌ RMI Connection failed: " + e.getMessage());
    }
}


    private Integer parseInt(String input) {
        return input.isEmpty() ? null : Integer.parseInt(input);
    }

    private Double parseDouble(String input) {
        return input.isEmpty() ? null : Double.parseDouble(input);
    }

    private void clearFields(TextField... fields) {
        for (TextField f : fields) f.clear();
    }

    private String btnStyle() {
        return "-fx-font-size: 16px; -fx-background-color: teal; -fx-text-fill: white; -fx-font-weight: bold;";
    }

    public static void main(String[] args) {
        launch(args);
    }

    
}
